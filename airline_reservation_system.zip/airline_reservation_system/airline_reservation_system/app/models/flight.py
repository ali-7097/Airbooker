from app import db
from datetime import datetime

class Flight(db.Model):
    __tablename__ = 'flight'
    
    flight_id = db.Column(db.Integer, primary_key=True)
    airline_id = db.Column(db.Integer, db.ForeignKey('airlines.airline_id'), nullable=False)
    aircraft_id = db.Column(db.Integer, db.ForeignKey('aircraft.aircraft_id'), nullable=False)
    flight_number = db.Column(db.String(10), nullable=False)
    flight_type = db.Column(db.String(20))  # domestic/international
    departure_city = db.Column(db.String(100), nullable=False)
    arrival_city = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.DateTime, nullable=False)
    arrival_time = db.Column(db.DateTime, nullable=False)
    flight_status = db.Column(db.String(20), default='Scheduled')  # Scheduled, Delayed, Cancelled, Completed
    available_seats = db.Column(db.Integer)
    gate_number = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    reservations = db.relationship('Reservation', backref='flight', lazy=True)
    prices = db.relationship('Price', backref='flight', lazy=True)
    
    def calculate_duration(self):
        return self.arrival_time - self.departure_time
    
    def update_available_seats(self):
        total_seats = self.aircraft.capacity
        booked_seats = sum(1 for reservation in self.reservations if reservation.status == 'confirmed' and reservation.seat_number)
        self.available_seats = total_seats - booked_seats 