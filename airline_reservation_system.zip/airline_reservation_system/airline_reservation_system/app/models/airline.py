from app import db

class Airline(db.Model):
    __tablename__ = 'airlines'
    
    airline_id = db.Column(db.Integer, primary_key=True)
    airline_name = db.Column(db.String(100), nullable=False)
    customer_support_email = db.Column(db.String(120))
    iata_code = db.Column(db.String(3), unique=True)
    icao_code = db.Column(db.String(4), unique=True)
    country = db.Column(db.String(50))
    headquarters_address = db.Column(db.String(200))
    
    # Relationships
    aircraft = db.relationship('Aircraft', backref='airline', lazy=True)
    flights = db.relationship('Flight', backref='airline', lazy=True)
    prices = db.relationship('Price', backref='airline', lazy=True) 