from app import db
from datetime import datetime

class ReservationPassenger(db.Model):
    __tablename__ = 'reservation_passengers'
    
    id = db.Column(db.Integer, primary_key=True)
    reservation_id = db.Column(db.Integer, db.ForeignKey('reservation.reservation_id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    passport_number = db.Column(db.String(20), nullable=False)
    gender = db.Column(db.String(10))
    date_of_birth = db.Column(db.Date)
    nationality = db.Column(db.String(50))
    seat_number = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship
    reservation = db.relationship('Reservation', backref='additional_passengers', lazy=True)
    
    def __repr__(self):
        return f'<ReservationPassenger {self.name}>' 