from app import db
from datetime import datetime

class DiscountRequest(db.Model):
    __tablename__ = 'discount_requests'
    
    request_id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('passenger.passenger_id'), nullable=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.flight_id'), nullable=False)
    reason = db.Column(db.Text, nullable=False)
    requested_discount = db.Column(db.Float)  # Percentage of discount requested
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    approved_discount = db.Column(db.Float)  # Actual discount approved by admin
    admin_notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)
    
    # Relationships
    user = db.relationship('User', backref='discount_requests', lazy=True)
    flight = db.relationship('Flight', backref='discount_requests', lazy=True)
    
    def __repr__(self):
        return f'<DiscountRequest {self.request_id}>' 