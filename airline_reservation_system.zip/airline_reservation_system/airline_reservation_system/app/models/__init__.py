from app import db
from .user import User
from .reservation import Reservation
from .flight import Flight
from .discount_request import DiscountRequest
# Add other models as needed 