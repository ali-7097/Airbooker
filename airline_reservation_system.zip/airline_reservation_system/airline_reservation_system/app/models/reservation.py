from app import db
from datetime import datetime

class Reservation(db.Model):
    __tablename__ = 'reservation'
    
    reservation_id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.flight_id'), nullable=False)
    passenger_id = db.Column(db.Integer, db.ForeignKey('passenger.passenger_id'), nullable=False)
    reservation_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='booked')  # booked, confirmed, cancelled
    ticket_type = db.Column(db.String(20), nullable=False)  # economy, business, first
    payment_status = db.Column(db.String(20), default='pending')
    seat_number = db.Column(db.String(10))  # Single seat number
    cancellation_status = db.Column(db.Boolean, default=False)
    cancellation_date = db.Column(db.DateTime)
    special_requests = db.Column(db.Text)
    check_in_status = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    booking_type = db.Column(db.String(20), default='reserved')  # reserved, purchased
    
    # Relationships
    invoices = db.relationship('Invoice', backref='reservation', lazy=True)
    
    def cancel_reservation(self):
        self.cancellation_status = True
        self.cancellation_date = datetime.utcnow()
        self.status = 'cancelled'
        
    def confirm_reservation(self):
        self.status = 'confirmed'
        self.payment_status = 'paid'
        
    def check_in(self):
        self.check_in_status = True 
        
    def purchase_ticket(self):
        self.booking_type = 'purchased'
        
    def __repr__(self):
        return f'<Reservation {self.reservation_id}>' 