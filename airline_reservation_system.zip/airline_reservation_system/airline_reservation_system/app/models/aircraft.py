from app import db

class Aircraft(db.Model):
    __tablename__ = 'aircraft'
    
    aircraft_id = db.Column(db.Integer, primary_key=True)
    airline_id = db.Column(db.Integer, db.ForeignKey('airlines.airline_id'), nullable=False)
    aircraft_type = db.Column(db.String(50), nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    registration_number = db.Column(db.String(20), unique=True)
    manufacturing_year = db.Column(db.Integer)
    
    # Relationships
    flights = db.relationship('Flight', backref='aircraft', lazy=True) 