from app import db
from datetime import datetime

class Price(db.Model):
    __tablename__ = 'prices'
    
    price_id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.flight_id'), nullable=False)
    airline_id = db.Column(db.Integer, db.ForeignKey('airlines.airline_id'), nullable=False)
    class_type = db.Column(db.String(20), nullable=False)  # Economy, Business, First
    base_fare = db.Column(db.Float, nullable=False)
    taxes = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(3), default='USD')
    discount = db.Column(db.Float, default=0.0)
    baggage_allowance = db.Column(db.Integer, nullable=False)  # in kg
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    
    def calculate_total(self):
        total = self.base_fare + self.taxes
        if self.discount > 0:
            total = total * (1 - self.discount)
        return round(total, 2)
    
    def __init__(self, *args, **kwargs):
        super(Price, self).__init__(*args, **kwargs)
        # Set default baggage allowance based on class type
        if not self.baggage_allowance:
            if self.class_type == 'Economy':
                self.baggage_allowance = 23  # 23kg for Economy
            elif self.class_type == 'Business':
                self.baggage_allowance = 32  # 32kg for Business
            elif self.class_type == 'First':
                self.baggage_allowance = 50  # 50kg for First 