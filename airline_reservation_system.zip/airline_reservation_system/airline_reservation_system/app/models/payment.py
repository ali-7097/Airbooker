from app import db
from datetime import datetime

class Payment(db.Model):
    __tablename__ = 'payments'
    
    payment_id = db.Column(db.Integer, primary_key=True)
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.invoice_id'), nullable=False)
    payment_date = db.Column(db.DateTime, default=datetime.utcnow)
    amount = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)
    payment_status = db.Column(db.String(20), default='pending')
    transaction_id = db.Column(db.String(100), unique=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def process_payment(self):
        if self.payment_status == 'pending':
            # Here we would typically integrate with a payment gateway
            # For now, we'll just simulate a successful payment
            self.payment_status = 'completed'
            self.invoice.status = 'paid'
            return True
        return False 