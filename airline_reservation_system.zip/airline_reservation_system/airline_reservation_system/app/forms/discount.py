from flask_wtf import FlaskForm
from wtforms import TextAreaField, FloatField
from wtforms.validators import DataRequired, NumberRange

class DiscountRequestForm(FlaskForm):
    reason = TextAreaField('Reason for Discount', validators=[DataRequired()])
    requested_discount = FloatField('Requested Discount (%)', 
                                  validators=[DataRequired(), 
                                            NumberRange(min=0, max=100, 
                                                      message="Discount must be between 0 and 100 percent")]) 