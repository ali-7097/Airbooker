from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, DateTimeField
from wtforms.validators import DataRequired, Length

class AddFlightForm(FlaskForm):
    flight_number = StringField('Flight Number', validators=[DataRequired(), Length(min=2, max=10)])
    airline_id = SelectField('Airline', coerce=int, validators=[DataRequired()])
    aircraft_id = SelectField('Aircraft', coerce=int, validators=[DataRequired()])
    flight_type = SelectField('Flight Type', choices=[
        ('domestic', 'Domestic'),
        ('international', 'International')
    ], validators=[DataRequired()])
    departure_city = StringField('Departure City', validators=[DataRequired(), Length(max=100)])
    arrival_city = StringField('Arrival City', validators=[DataRequired(), Length(max=100)])
    departure_time = DateTimeField('Departure Time', format='%Y-%m-%dT%H:%M', validators=[DataRequired()])
    arrival_time = DateTimeField('Arrival Time', format='%Y-%m-%dT%H:%M', validators=[DataRequired()])
    gate_number = StringField('Gate Number', validators=[DataRequired(), Length(max=10)]) 