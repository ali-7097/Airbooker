from flask import Blueprint, render_template, request, jsonify
from flask_login import current_user, login_required
from app.models.flight import Flight
from app.models.airline import Airline
from app.models.price import Price
from datetime import datetime
from sqlalchemy import and_

bp = Blueprint('main', __name__)

@bp.route('/')
@login_required
def index():
    # Get featured flights (e.g., upcoming flights with good deals)
    featured_flights = Flight.query.join(Price).filter(
        and_(
            Flight.departure_time > datetime.utcnow(),
            Flight.flight_status == 'Scheduled'
        )
    ).limit(6).all()
    
    # Get all available airlines
    airlines = Airline.query.all()
    
    return render_template('main/index.html',
                         featured_flights=featured_flights,
                         airlines=airlines,
                         user=current_user)

@bp.route('/search', methods=['GET'])
def search_flights():
    departure_city = request.args.get('departure')
    arrival_city = request.args.get('arrival')
    departure_date = request.args.get('date')
    flight_class = request.args.get('class', 'Economy')
    
    # Convert string date to datetime
    try:
        departure_date = datetime.strptime(departure_date, '%Y-%m-%d')
    except (ValueError, TypeError):
        departure_date = None
    
    # Build the query
    query = Flight.query.join(Price)
    
    if departure_city:
        query = query.filter(Flight.departure_city.ilike(f'%{departure_city}%'))
    if arrival_city:
        query = query.filter(Flight.arrival_city.ilike(f'%{arrival_city}%'))
    if departure_date:
        query = query.filter(
            and_(
                Flight.departure_time >= departure_date,
                Flight.departure_time < departure_date.replace(hour=23, minute=59, second=59)
            )
        )
    
    # Filter by flight status and future dates
    query = query.filter(
        and_(
            Flight.departure_time > datetime.utcnow(),
            Flight.flight_status == 'Scheduled'
        )
    )
    
    flights = query.all()
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        # Return JSON for AJAX requests
        return jsonify([{
            'id': flight.flight_id,
            'airline': flight.airline.airline_name,
            'flight_number': flight.flight_number,
            'departure_city': flight.departure_city,
            'arrival_city': flight.arrival_city,
            'departure_time': flight.departure_time.strftime('%Y-%m-%d %H:%M'),
            'arrival_time': flight.arrival_time.strftime('%Y-%m-%d %H:%M'),
            'price': next((p.calculate_total() for p in flight.prices if p.class_type == flight_class), None),
            'available_seats': flight.available_seats
        } for flight in flights])
    
    return render_template('main/search.html',
                         flights=flights,
                         departure_city=departure_city,
                         arrival_city=arrival_city,
                         departure_date=departure_date,
                         flight_class=flight_class) 