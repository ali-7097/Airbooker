from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models import Flight, Reservation, db
from datetime import datetime

bp = Blueprint('flight', __name__)

@bp.route('/flights')
def list_flights():
    flights = Flight.query.all()
    return render_template('flight/list.html', flights=flights)

@bp.route('/flight/<int:flight_id>')
def view_flight(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    return render_template('booking/flight_details.html', flight=flight)

@bp.route('/flight/<int:flight_id>/reserve', methods=['POST'])
@login_required
def reserve_flight(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    
    if flight.available_seats <= 0:
        flash('Sorry, this flight is fully booked.', 'danger')
        return redirect(url_for('flight.view_flight', flight_id=flight_id))
    
    reservation = Reservation(
        user_id=current_user.id,
        flight_id=flight_id,
        status='pending'
    )
    
    flight.available_seats -= 1
    db.session.add(reservation)
    db.session.commit()
    
    flash('Flight reserved successfully!', 'success')
    return redirect(url_for('profile.view_profile'))

@bp.route('/flight/<int:flight_id>/cancel', methods=['POST'])
@login_required
def cancel_flight(flight_id):
    reservation = Reservation.query.filter_by(
        user_id=current_user.id,
        flight_id=flight_id,
        status='pending'
    ).first_or_404()
    
    flight = Flight.query.get(flight_id)
    flight.available_seats += 1
    
    db.session.delete(reservation)
    db.session.commit()
    
    flash('Flight reservation cancelled.', 'info')
    return redirect(url_for('profile.view_profile'))

@bp.route('/admin/flight/add', methods=['GET', 'POST'])
@login_required
def add_flight():
    if not current_user.is_admin:
        flash('Unauthorized access.', 'danger')
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        # Add flight logic here
        pass
    
    return render_template('admin/add_flight.html')

@bp.route('/admin/flight/<int:flight_id>/cancel', methods=['POST'])
@login_required
def cancel_flight_admin(flight_id):
    if not current_user.is_admin:
        flash('Unauthorized access.', 'danger')
        return redirect(url_for('main.index'))
    
    flight = Flight.query.get_or_404(flight_id)
    flight.flight_status = 'Cancelled'
    
    # Cancel all reservations for this flight
    reservations = Reservation.query.filter_by(flight_id=flight_id).all()
    for reservation in reservations:
        reservation.cancel_reservation()
    
    db.session.commit()
    flash('Flight has been cancelled and all reservations have been refunded.', 'success')
    return redirect(url_for('admin.flights')) 