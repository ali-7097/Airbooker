from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models import User, db
from app.models.reservation import Reservation
from app.forms.profile import ProfileForm

bp = Blueprint('profile', __name__)

@bp.route('/profile')
@login_required
def view_profile():
    form = ProfileForm(obj=current_user)
    if form.validate_on_submit():
        current_user.name = form.name.data
        current_user.phone_number = form.phone_number.data
        current_user.address = form.address.data
        current_user.passport_number = form.passport_number.data
        current_user.nationality = form.nationality.data
        current_user.date_of_birth = form.date_of_birth.data
        current_user.gender = form.gender.data
        
        db.session.commit()
        flash('Your profile has been updated.', 'success')
        return redirect(url_for('profile.view_profile'))
    
    # Get user's reservations
    reservations = Reservation.query.filter_by(passenger_id=current_user.passenger_id)\
        .order_by(Reservation.created_at.desc()).all()
    
    return render_template('user/profile.html', user=current_user)

@bp.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        current_user.name = request.form.get('name')
        current_user.phone_number = request.form.get('phone')
        current_user.address = request.form.get('address')
        current_user.nationality = request.form.get('nationality')
        current_user.passport_number = request.form.get('passport')
        current_user.gender = request.form.get('gender')
        
        if request.form.get('date_of_birth'):
            from datetime import datetime
            current_user.date_of_birth = datetime.strptime(request.form.get('date_of_birth'), '%Y-%m-%d').date()
        
        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile.view_profile'))
    
    return render_template('user/edit_profile.html', user=current_user)

@bp.route('/profile/reservation/<int:reservation_id>/purchase', methods=['POST'])
@login_required
def purchase_ticket(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    
    if reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access.', 'danger')
        return redirect(url_for('profile.view_profile'))
    
    if reservation.booking_type == 'purchased':
        flash('Ticket already purchased.', 'warning')
        return redirect(url_for('profile.view_profile'))
    
    reservation.purchase_ticket()
    db.session.commit()
    
    flash('Ticket purchased successfully!', 'success')
    return redirect(url_for('profile.view_profile'))

@bp.route('/profile/reservation/<int:reservation_id>/cancel', methods=['POST'])
@login_required
def cancel_reservation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    
    if reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access.', 'danger')
        return redirect(url_for('profile.view_profile'))
    
    if reservation.status == 'cancelled':
        flash('Reservation already cancelled.', 'warning')
        return redirect(url_for('profile.view_profile'))
    
    reservation.cancel_reservation()
    db.session.commit()
    
    flash('Reservation cancelled successfully.', 'success')
    return redirect(url_for('profile.view_profile')) 