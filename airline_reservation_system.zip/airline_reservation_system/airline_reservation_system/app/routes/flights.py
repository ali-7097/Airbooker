from flask import render_template, request, jsonify, Blueprint
from app.models.flight import Flight
from datetime import datetime

flights_bp = Blueprint('flights', __name__, url_prefix='/flights')

@flights_bp.route('/search', methods=['GET', 'POST'])
def search_flights():
    if request.method == 'POST':
        departure_city = request.form.get('departure_city')
        arrival_city = request.form.get('arrival_city')
        departure_date = request.form.get('departure_date')
        flight_type = request.form.get('flight_type', 'any')
        
        # Convert string date to datetime
        try:
            departure_date = datetime.strptime(departure_date, '%Y-%m-%d')
        except (ValueError, TypeError):
            return jsonify({'error': 'Invalid date format'}), 400
        
        # Base query
        query = Flight.query.filter(
            Flight.departure_city.ilike(f'%{departure_city}%'),
            Flight.arrival_city.ilike(f'%{arrival_city}%'),
            Flight.departure_time >= departure_date,
            Flight.departure_time < departure_date.replace(hour=23, minute=59, second=59),
            Flight.flight_status != 'Cancelled'
        )
        
        # Add flight type filter if specified
        if flight_type != 'any':
            query = query.filter(Flight.flight_type == flight_type)
        
        # Get available flights
        flights = query.all()
        
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            # Return JSON for AJAX requests
            return jsonify([{
                'flight_number': flight.flight_number,
                'airline': flight.airline.name,
                'departure_city': flight.departure_city,
                'arrival_city': flight.arrival_city,
                'departure_time': flight.departure_time.strftime('%H:%M'),
                'arrival_time': flight.arrival_time.strftime('%H:%M'),
                'available_seats': flight.available_seats,
                'prices': [{'class': price.ticket_class, 'amount': price.amount} for price in flight.prices]
            } for flight in flights])
        
        return render_template('flights/search_results.html', flights=flights)
    
    return render_template('flights/search.html')

@flights_bp.route('/flight/<int:flight_id>')
def flight_details(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    return render_template('flights/details.html', flight=flight) 