from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models import DiscountRequest, db

bp = Blueprint('discount', __name__)

@bp.route('/discount/request', methods=['GET', 'POST'])
@login_required
def request_discount():
    if request.method == 'POST':
        reason = request.form.get('reason')
        amount = float(request.form.get('amount'))
        
        request = DiscountRequest(
            user_id=current_user.id,
            reason=reason,
            amount=amount,
            status='pending'
        )
        
        db.session.add(request)
        db.session.commit()
        
        flash('Discount request submitted successfully!', 'success')
        return redirect(url_for('profile.view_profile'))
    
    return render_template('discount/request.html')

@bp.route('/discount/requests')
@login_required
def view_requests():
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('main.index'))
    
    requests = DiscountRequest.query.order_by(DiscountRequest.created_at.desc()).all()
    return render_template('discount/requests.html', requests=requests)

@bp.route('/discount/request/<int:request_id>/approve', methods=['POST'])
@login_required
def approve_request(request_id):
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('main.index'))
    
    request = DiscountRequest.query.get_or_404(request_id)
    request.status = 'approved'
    db.session.commit()
    
    flash('Discount request approved!', 'success')
    return redirect(url_for('discount.view_requests'))

@bp.route('/discount/request/<int:request_id>/reject', methods=['POST'])
@login_required
def reject_request(request_id):
    if not current_user.is_admin:
        flash('Access denied.', 'danger')
        return redirect(url_for('main.index'))
    
    request = DiscountRequest.query.get_or_404(request_id)
    request.status = 'rejected'
    db.session.commit()
    
    flash('Discount request rejected.', 'info')
    return redirect(url_for('discount.view_requests')) 