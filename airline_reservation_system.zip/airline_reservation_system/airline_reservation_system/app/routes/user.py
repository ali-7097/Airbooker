from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user
from app import db
from app.models.user import User
from app.models.reservation import Reservation
from datetime import datetime

user_bp = Blueprint('user', __name__, url_prefix='/profile')

@user_bp.route('/')
@login_required
def profile():
    return render_template('user/profile.html', user=current_user)

@user_bp.route('/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        current_user.name = request.form.get('name')
        current_user.phone_number = request.form.get('phone_number')
        current_user.address = request.form.get('address')
        current_user.passport_number = request.form.get('passport_number')
        current_user.nationality = request.form.get('nationality')
        
        if request.form.get('date_of_birth'):
            current_user.date_of_birth = datetime.strptime(
                request.form.get('date_of_birth'), 
                '%Y-%m-%d'
            ).date()
        
        try:
            db.session.commit()
            flash('Profile updated successfully', 'success')
            return redirect(url_for('profile.view_profile'))
        except Exception as e:
            db.session.rollback()
            flash('Error updating profile', 'danger')
    
    return render_template('user/edit_profile.html', user=current_user)

@user_bp.route('/bookings')
@login_required
def bookings():
    reservations = Reservation.query.filter_by(
        passenger_id=current_user.passenger_id
    ).order_by(Reservation.created_at.desc()).all()
    return render_template('user/bookings.html', reservations=reservations)

@user_bp.route('/booking/<int:reservation_id>')
@login_required
def booking_details(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    
    # Ensure user can only view their own bookings
    if reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('user.bookings'))
    
    return render_template('user/booking_details.html', reservation=reservation)

@user_bp.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if not current_user.check_password(current_password):
            flash('Current password is incorrect', 'danger')
            return redirect(url_for('profile.view_profile'))
        
        if new_password != confirm_password:
            flash('New passwords do not match', 'danger')
            return redirect(url_for('profile.view_profile'))
        
        current_user.set_password(new_password)
        db.session.commit()
        flash('Password changed successfully', 'success')
        return redirect(url_for('profile.view_profile'))
    
    return render_template('user/change_password.html') 