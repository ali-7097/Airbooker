from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify
from flask_login import login_required, current_user
from app import db
from app.models.flight import Flight
from app.models.airline import Airline
from app.models.aircraft import Aircraft
from app.models.price import Price
from app.models.user import User
from app.models.reservation import Reservation
from datetime import datetime
from functools import wraps

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You do not have permission to access this page.', 'error')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/')
@login_required
@admin_required
def dashboard():
    # Get statistics for the dashboard
    total_flights = Flight.query.count()
    total_users = User.query.count()
    total_reservations = Reservation.query.count()
    recent_bookings = Reservation.query.order_by(Reservation.created_at.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html',
                         total_flights=total_flights,
                         total_users=total_users,
                         total_reservations=total_reservations,
                         recent_bookings=recent_bookings)

@admin_bp.route('/flights')
@login_required
@admin_required
def flights():
    flights = Flight.query.order_by(Flight.departure_time.desc()).all()
    return render_template('admin/flights.html', flights=flights)

@admin_bp.route('/flight/new', methods=['GET', 'POST'])
@login_required
@admin_required
def new_flight():
    if request.method == 'POST':
        airline_id = request.form.get('airline_id')
        aircraft_id = request.form.get('aircraft_id')
        flight_number = request.form.get('flight_number')
        departure_city = request.form.get('departure_city')
        arrival_city = request.form.get('arrival_city')
        departure_time = datetime.strptime(request.form.get('departure_time'), '%Y-%m-%dT%H:%M')
        arrival_time = datetime.strptime(request.form.get('arrival_time'), '%Y-%m-%dT%H:%M')
        
        flight = Flight(
            airline_id=airline_id,
            aircraft_id=aircraft_id,
            flight_number=flight_number,
            departure_city=departure_city,
            arrival_city=arrival_city,
            departure_time=departure_time,
            arrival_time=arrival_time
        )
        
        # Add prices for different classes
        for class_type in ['Economy', 'Business', 'First']:
            base_fare = request.form.get(f'{class_type.lower()}_price')
            if base_fare:
                price = Price(
                    flight=flight,
                    class_type=class_type,
                    base_fare=float(base_fare),
                    taxes=float(request.form.get(f'{class_type.lower()}_tax', 0))
                )
                db.session.add(price)
        
        try:
            db.session.add(flight)
            db.session.commit()
            flash('Flight created successfully', 'success')
            return redirect(url_for('admin.flights'))
        except Exception as e:
            db.session.rollback()
            flash('Error creating flight', 'error')
    
    airlines = Airline.query.all()
    aircraft = Aircraft.query.all()
    return render_template('admin/flight_form.html',
                         airlines=airlines,
                         aircraft=aircraft)

@admin_bp.route('/flight/<int:flight_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_flight(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    
    if request.method == 'POST':
        flight.flight_number = request.form.get('flight_number')
        flight.departure_city = request.form.get('departure_city')
        flight.arrival_city = request.form.get('arrival_city')
        flight.departure_time = datetime.strptime(request.form.get('departure_time'), '%Y-%m-%dT%H:%M')
        flight.arrival_time = datetime.strptime(request.form.get('arrival_time'), '%Y-%m-%dT%H:%M')
        flight.flight_status = request.form.get('status')
        
        # Update prices
        for price in flight.prices:
            base_fare = request.form.get(f'{price.class_type.lower()}_price')
            if base_fare:
                price.base_fare = float(base_fare)
                price.taxes = float(request.form.get(f'{price.class_type.lower()}_tax', 0))
        
        try:
            db.session.commit()
            flash('Flight updated successfully', 'success')
            return redirect(url_for('admin.flights'))
        except Exception as e:
            db.session.rollback()
            flash('Error updating flight', 'error')
    
    return render_template('admin/flight_form.html',
                         flight=flight,
                         airlines=Airline.query.all(),
                         aircraft=Aircraft.query.all())

@admin_bp.route('/flight/<int:flight_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_flight(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    
    try:
        db.session.delete(flight)
        db.session.commit()
        flash('Flight deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting flight', 'error')
    
    return redirect(url_for('admin.flights'))

@admin_bp.route('/users')
@login_required
@admin_required
def users():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=users)

@admin_bp.route('/reservations')
@login_required
@admin_required
def reservations():
    reservations = Reservation.query.order_by(Reservation.created_at.desc()).all()
    return render_template('admin/reservations.html', reservations=reservations)

@admin_bp.route('/airlines')
@login_required
@admin_required
def airlines():
    airlines = Airline.query.all()
    return render_template('admin/airlines.html', airlines=airlines)

@admin_bp.route('/airline/new', methods=['GET', 'POST'])
@login_required
@admin_required
def new_airline():
    if request.method == 'POST':
        airline = Airline(
            airline_name=request.form.get('name'),
            iata_code=request.form.get('iata_code'),
            icao_code=request.form.get('icao_code'),
            country=request.form.get('country'),
            headquarters_address=request.form.get('address'),
            customer_support_email=request.form.get('email')
        )
        
        try:
            db.session.add(airline)
            db.session.commit()
            flash('Airline created successfully', 'success')
            return redirect(url_for('admin.airlines'))
        except Exception as e:
            db.session.rollback()
            flash('Error creating airline', 'error')
    
    return render_template('admin/airline_form.html')

@admin_bp.route('/user/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.is_admin:
        flash('Cannot delete another admin.', 'danger')
        return redirect(url_for('admin.users'))
    try:
        db.session.delete(user)
        db.session.commit()
        flash('User deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting user.', 'danger')
    return redirect(url_for('admin.users')) 