from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required, current_user
from app import db
from app.models.flight import Flight
from app.models.reservation import Reservation
from app.models.invoice import Invoice
from app.models.payment import Payment
from datetime import datetime
import uuid

booking_bp = Blueprint('booking', __name__)

@booking_bp.route('/flight/<int:flight_id>')
def flight_details(flight_id):
    if current_user.is_authenticated and current_user.is_admin:
        flash('Admins cannot book or purchase tickets.', 'danger')
        return redirect(url_for('main.index'))
    flight = Flight.query.get_or_404(flight_id)
    return render_template('booking/flight_details.html', flight=flight)

@booking_bp.route('/flight/<int:flight_id>/seats')
@login_required
def seat_selection(flight_id):
    if current_user.is_admin:
        flash('Admins cannot book or purchase tickets.', 'danger')
        return redirect(url_for('main.index'))
    flight = Flight.query.get_or_404(flight_id)
    selected_class = request.args.get('class', 'Economy')
    
    # Validate class type
    if selected_class not in ['Economy', 'Business', 'First']:
        selected_class = 'Economy'
    
    # Get all reserved seats for this flight
    reserved_seats = set()
    for reservation in flight.reservations:
        if reservation.seat_number:
            reserved_seats.add(reservation.seat_number)
    
    return render_template('booking/seat_selection.html',
                         flight=flight,
                         reserved_seats=reserved_seats,
                         selected_class=selected_class)

@booking_bp.route('/my-bookings')
@login_required
def my_bookings():
    reservations = Reservation.query.filter_by(
        passenger_id=current_user.passenger_id
    ).order_by(Reservation.created_at.desc()).all()
    return render_template('booking/my_bookings.html', reservations=reservations)

@booking_bp.route('/confirm-booking/<int:flight_id>', methods=['POST'])
@login_required
def confirm_booking(flight_id):
    if current_user.is_admin:
        flash('Admins cannot book or purchase tickets.', 'danger')
        return redirect(url_for('main.index'))
    flight = Flight.query.get_or_404(flight_id)
    selected_seat = request.form.get('selected_seat')
    selected_class = request.args.get('class', 'Economy')
    action = request.form.get('action', 'purchase')

    if not selected_seat:
        flash('Please select a seat', 'error')
        return redirect(url_for('booking.seat_selection', flight_id=flight_id, class_=selected_class))

    # Check if user already has a reservation for this flight
    existing_reservation = Reservation.query.filter_by(
        flight_id=flight_id,
        passenger_id=current_user.passenger_id
    ).first()
    if existing_reservation:
        flash('You have already booked a seat on this flight.', 'error')
        return redirect(url_for('booking.my_bookings'))

    # Check if seat is already reserved
    reserved_seats = set()
    for reservation in flight.reservations:
        if reservation.seat_number:
            reserved_seats.add(reservation.seat_number)
    if selected_seat in reserved_seats:
        flash('Selected seat is no longer available. Please choose a different seat.', 'error')
        return redirect(url_for('booking.seat_selection', flight_id=flight_id, class_=selected_class))

    # Create reservation
    reservation = Reservation(
        flight_id=flight_id,
        passenger_id=current_user.passenger_id,
        ticket_type=selected_class,
        seat_number=selected_seat,
        status='pending'
    )

    try:
        db.session.add(reservation)
        
        if action == 'purchase':
            # Calculate total price based on selected class
            price = next((p for p in flight.prices if p.class_type == selected_class), None)
            if not price:
                flash('Error calculating price. Please try again.', 'error')
                return redirect(url_for('booking.seat_selection', flight_id=flight_id, class_=selected_class))

            total_amount = price.calculate_total()

            # Create invoice for purchase
            invoice = Invoice(
                reservation=reservation,
                total_amount=total_amount,
                invoice_number=f'INV-{uuid.uuid4().hex[:8].upper()}',
                currency=price.currency
            )
            db.session.add(invoice)
            db.session.commit()
            return redirect(url_for('booking.payment', invoice_id=invoice.invoice_id))
        else:  # action == 'book'
            db.session.commit()
            flash('Seat reserved! Complete your purchase from My Bookings when ready.', 'success')
            return redirect(url_for('booking.my_bookings'))
            
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while processing your booking. Please try again.', 'error')
        return redirect(url_for('booking.seat_selection', flight_id=flight_id, class_=selected_class))

@booking_bp.route('/payment/<int:invoice_id>')
@login_required
def payment(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    if invoice.reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('main.index'))
    return render_template('booking/payment.html', invoice=invoice)

@booking_bp.route('/process-payment/<int:invoice_id>', methods=['POST'])
@login_required
def process_payment(invoice_id):
    invoice = Invoice.query.get_or_404(invoice_id)
    if invoice.reservation.passenger_id != current_user.passenger_id:
        return jsonify({'error': 'Unauthorized access'}), 403
    
    payment_method = request.form.get('payment_method')
    if not payment_method:
        return jsonify({'error': 'Payment method is required'}), 400
    
    # Create payment record
    payment = Payment(
        invoice=invoice,
        amount=invoice.total_amount,
        payment_method=payment_method,
        transaction_id=f'TXN-{uuid.uuid4().hex[:12].upper()}'
    )
    
    try:
        # Process payment (mock implementation)
        payment.status = 'completed'
        # Update reservation status
        invoice.reservation.status = 'confirmed'
        invoice.reservation.payment_status = 'paid'
        
        # Update flight's available seats
        flight = invoice.reservation.flight
        flight.update_available_seats()
        
        db.session.add(payment)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'redirect_url': url_for('booking.confirmation', reservation_id=invoice.reservation_id)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@booking_bp.route('/confirmation/<int:reservation_id>')
@login_required
def confirmation(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    if reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('main.index'))
    return render_template('booking/confirmation.html', reservation=reservation)

@booking_bp.route('/ticket/<int:reservation_id>')
@login_required
def view_ticket(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    
    # Ensure user can only view their own tickets
    if reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('booking.my_bookings'))
    
    return render_template('booking/ticket.html', reservation=reservation)

@booking_bp.route('/check-in/<int:reservation_id>', methods=['POST'])
@login_required
def check_in(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    
    # Ensure user can only check in for their own reservations
    if reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('booking.my_bookings'))
    
    # Verify reservation is confirmed and not already checked in
    if reservation.status != 'confirmed':
        flash('Cannot check in - booking is not confirmed', 'error')
        return redirect(url_for('booking.view_ticket', reservation_id=reservation_id))
        
    if reservation.check_in_status:
        flash('Already checked in', 'info')
        return redirect(url_for('booking.view_ticket', reservation_id=reservation_id))
    
    # Check if within check-in window (24 hours before flight)
    now = datetime.utcnow()
    flight_time = reservation.flight.departure_time
    hours_until_flight = (flight_time - now).total_seconds() / 3600
    
    if hours_until_flight > 24:
        flash('Online check-in opens 24 hours before flight departure', 'info')
        return redirect(url_for('booking.view_ticket', reservation_id=reservation_id))
    
    if hours_until_flight < 0:
        flash('Flight has already departed', 'error')
        return redirect(url_for('booking.view_ticket', reservation_id=reservation_id))
    
    # Perform check-in
    reservation.check_in_status = True
    try:
        db.session.commit()
        flash('Successfully checked in', 'success')
    except Exception as e:
        db.session.rollback()
        flash('An error occurred during check-in. Please try again.', 'error')
    
    return redirect(url_for('booking.view_ticket', reservation_id=reservation_id))

@booking_bp.route('/purchase-booked-ticket/<int:reservation_id>')
@login_required
def purchase_booked_ticket(reservation_id):
    reservation = Reservation.query.get_or_404(reservation_id)
    
    # Ensure user can only purchase their own tickets
    if reservation.passenger_id != current_user.passenger_id:
        flash('Unauthorized access', 'error')
        return redirect(url_for('booking.my_bookings'))
    
    # Check if reservation is pending
    if reservation.status != 'pending':
        flash('This reservation cannot be purchased', 'error')
        return redirect(url_for('booking.my_bookings'))
    
    # Check if an invoice already exists
    existing_invoice = Invoice.query.filter_by(reservation_id=reservation_id).first()
    if existing_invoice:
        return redirect(url_for('booking.payment', invoice_id=existing_invoice.invoice_id))
    
    # Calculate total price based on ticket class
    price = next((p for p in reservation.flight.prices if p.class_type == reservation.ticket_type), None)
    if not price:
        flash('Error calculating price. Please try again.', 'error')
        return redirect(url_for('booking.my_bookings'))
    
    total_amount = price.calculate_total()
    
    # Create invoice
    invoice = Invoice(
        reservation=reservation,
        total_amount=total_amount,
        invoice_number=f'INV-{uuid.uuid4().hex[:8].upper()}',
        currency=price.currency
    )
    
    try:
        db.session.add(invoice)
        db.session.commit()
        return redirect(url_for('booking.payment', invoice_id=invoice.invoice_id))
    except Exception as e:
        db.session.rollback()
        flash('An error occurred while processing your purchase. Please try again.', 'error')
        return redirect(url_for('booking.my_bookings')) 