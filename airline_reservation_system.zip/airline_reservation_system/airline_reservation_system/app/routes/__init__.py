from flask import Blueprint

auth_bp = Blueprint('auth', __name__)
flight_bp = Blueprint('flight', __name__)
booking_bp = Blueprint('booking', __name__)
admin_bp = Blueprint('admin', __name__)
user_bp = Blueprint('user', __name__)

from . import auth, flights, booking, admin 