from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from app.models import User, db
from datetime import datetime

bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False

        user = User.query.filter_by(email=email).first()

        if not user or not user.check_password(password):
            flash('Please check your login details and try again.')
            return redirect(url_for('auth.login'))

        login_user(user, remember=remember)
        return redirect(url_for('main.index'))

    return render_template('auth/login.html')

@bp.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form.get('email')
        name = request.form.get('name')
        password = request.form.get('password')
        phone = request.form.get('phone')
        address = request.form.get('address')
        nationality = request.form.get('nationality')
        passport = request.form.get('passport')
        date_of_birth = request.form.get('date_of_birth')
        gender = request.form.get('gender')

        user = User.query.filter_by(email=email).first()

        if user:
            flash('Email address already exists')
            return redirect(url_for('auth.signup'))

        new_user = User(
            email=email,
            name=name,
            phone_number=phone,
            address=address,
            nationality=nationality,
            passport_number=passport,
            gender=gender
        )
        
        if date_of_birth:
            new_user.date_of_birth = datetime.strptime(date_of_birth, '%Y-%m-%d').date()
            
        new_user.set_password(password)

        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred during registration. Please try again.', 'error')
            return redirect(url_for('auth.signup'))

    return render_template('auth/register.html')

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))

@bp.route('/create-admin')
def create_admin():
    # Check if admin already exists
    admin = User.query.filter_by(email='admin@airbooker.com').first()
    if admin:
        flash('Admin account already exists', 'info')
        return redirect(url_for('auth.login'))
    
    # Create admin user
    admin = User(
        email='admin@airbooker.com',
        name='Admin',
        is_admin=True
    )
    admin.set_password('Admin@123')  # Set a secure password
    
    try:
        db.session.add(admin)
        db.session.commit()
        flash('Admin account created successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error creating admin account', 'error')
    
    return redirect(url_for('auth.login')) 