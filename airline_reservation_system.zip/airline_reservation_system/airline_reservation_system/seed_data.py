from app import create_app, db
from app.models.airline import Airline
from app.models.aircraft import Aircraft
from app.models.flight import Flight
from app.models.price import Price
from app.models.user import User
from datetime import datetime, timedelta

def seed_database():
    app = create_app()
    with app.app_context():
        # Create Airlines
        airlines = [
            Airline(
                airline_name='Pakistan International Airlines',
                customer_support_email='support@pia.com',
                iata_code='PK',
                icao_code='PIA',
                country='Pakistan',
                headquarters_address='PIA Building, Karachi Airport'
            ),
            Airline(
                airline_name='Emirates',
                customer_support_email='support@emirates.com',
                iata_code='EK',
                icao_code='UAE',
                country='United Arab Emirates',
                headquarters_address='Emirates Group Headquarters, Dubai'
            ),
            Airline(
                airline_name='Qatar Airways',
                customer_support_email='support@qatarairways.com',
                iata_code='QR',
                icao_code='QTR',
                country='Qatar',
                headquarters_address='Qatar Airways Tower, Doha'
            )
        ]
        db.session.add_all(airlines)
        db.session.commit()
        
        # Create Aircraft
        aircraft = [
            Aircraft(
                airline_id=1,
                aircraft_type='Boeing 777-300ER',
                registration_number='AP-BHV',
                capacity=350,
                manufacturing_year=2015
            ),
            Aircraft(
                airline_id=2,
                aircraft_type='Airbus A380-800',
                registration_number='A6-EVK',
                capacity=615,
                manufacturing_year=2018
            ),
            Aircraft(
                airline_id=3,
                aircraft_type='Boeing 787-9',
                registration_number='A7-BHD',
                capacity=311,
                manufacturing_year=2019
            )
        ]
        db.session.add_all(aircraft)
        db.session.commit()
        
        # Create Flights
        cities = ['Karachi', 'Lahore', 'Islamabad', 'Dubai', 'Doha', 'Abu Dhabi']
        current_time = datetime.utcnow()
        
        flights = []
        for i in range(20):
            departure_city = cities[i % 3]
            arrival_city = cities[(i + 1) % 6]
            departure_time = current_time + timedelta(days=i//3, hours=i*2)
            arrival_time = departure_time + timedelta(hours=3)
            
            flight = Flight(
                airline_id=(i % 3) + 1,
                aircraft_id=(i % 3) + 1,
                flight_number=f'FL{1000 + i}',
                departure_city=departure_city,
                arrival_city=arrival_city,
                departure_time=departure_time,
                arrival_time=arrival_time,
                flight_status='Scheduled',
                available_seats=100,
                flight_type='direct'
            )
            flights.append(flight)
        
        db.session.add_all(flights)
        db.session.commit()
        
        # Create Prices
        prices = []
        for flight in flights:
            # Economy Class
            prices.append(Price(
                flight_id=flight.flight_id,
                airline_id=flight.airline_id,
                class_type='Economy',
                base_fare=25000,
                taxes=5000,
                currency='PKR',
                discount=0.0,
                baggage_allowance=23  # 23kg for Economy
            ))
            # Business Class
            prices.append(Price(
                flight_id=flight.flight_id,
                airline_id=flight.airline_id,
                class_type='Business',
                base_fare=50000,
                taxes=10000,
                currency='PKR',
                discount=0.0,
                baggage_allowance=32  # 32kg for Business
            ))
            # First Class
            prices.append(Price(
                flight_id=flight.flight_id,
                airline_id=flight.airline_id,
                class_type='First',
                base_fare=100000,
                taxes=20000,
                currency='PKR',
                discount=0.0,
                baggage_allowance=50  # 50kg for First
            ))
        
        db.session.add_all(prices)
        db.session.commit()
        
        # Create Test Users
        test_user = User(
            email='test@example.com',
            name='Test User',
            phone_number='+923001234567',
            address='123 Test Street, Karachi',
            passport_number='AB1234567',
            nationality='Pakistani',
            date_of_birth=datetime(1990, 1, 1).date()
        )
        test_user.set_password('password123')
        
        admin_user = User(
            email='admin@airbooker.com',
            name='Admin User',
            phone_number='+923009876543',
            address='456 Admin Street, Lahore',
            passport_number='XY9876543',
            nationality='Pakistani',
            date_of_birth=datetime(1985, 1, 1).date(),
            is_admin=True
        )
        admin_user.set_password('admin123')
        
        db.session.add_all([test_user, admin_user])
        db.session.commit()
        
        print("Sample data has been added successfully!")
        print("\nTest User Credentials:")
        print("Email: test@example.com")
        print("Password: password123")
        print("\nAdmin User Credentials:")
        print("Email: admin@airbooker.com")
        print("Password: admin123")

if __name__ == '__main__':
    try:
        seed_database()
    except Exception as e:
        print(f"An error occurred: {e}") 