from app import create_app, db
from sqlalchemy import text

app = create_app()

with app.app_context():
    # Disable foreign key checks
    db.session.execute(text('SET FOREIGN_KEY_CHECKS = 0;'))
    
    # Drop all tables
    db.drop_all()
    
    # Re-enable foreign key checks
    db.session.execute(text('SET FOREIGN_KEY_CHECKS = 1;'))
    
    # Create all tables
    db.create_all()
    
    print("Database has been reset successfully!") 