import mysql.connector
from app import create_app, db

def reset_database():
    # Connect to MySQL
    conn = mysql.connector.connect(
        host="localhost",
        user="root",
        password="mali@123"
    )
    cursor = conn.cursor()
    
    try:
        # Drop and recreate the database
        cursor.execute("DROP DATABASE IF EXISTS airline_reservation")
        cursor.execute("CREATE DATABASE airline_reservation CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        conn.commit()
        
        print("Database dropped and recreated.")
        
        # Initialize Flask app and create tables
        app = create_app()
        with app.app_context():
            db.create_all()
            print("All tables created successfully!")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    reset_database() 